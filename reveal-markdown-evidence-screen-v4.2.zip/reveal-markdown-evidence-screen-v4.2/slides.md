<!-- .slide: class="team" data-stage="项目开场" data-transition="fade" -->
# 智证先锋
行车数据可信治理与事故判责平台

| ![项目经理](portraits/manager.png) | ![平台系统开发工程师](portraits/platform.png) | ![数字孪生工程师](portraits/twin.png) | ![软硬件调试工程师](portraits/hardware.png) |
| --- | --- | --- | --- |
| 项目经理 | 平台系统开发工程师 | 数字孪生工程师 | 软硬件调试工程师 |
| 统筹推进 · 系统联通 | 黑匣子 · 存证 · 交警端 | 仿真验证 · 三维重建 · VR | 设备接入 · DMS · 实体测试 |

---

<!-- .slide: class="problem" data-stage="项目理解" data-lead="manager" data-active="manager" data-role-detail="manager=说明事故证据的组织方式|把后续开发与测试统一到同一次事故" data-collab="manager=说明主线;platform=准备证据平台;hardware=准备车端与DMS;twin=准备仿真与三维" data-transition="fade" -->
# 事故证据按三个时段组织
驾驶行为、车辆响应和事故现场最终要能够对应到同一次事故

- **事故前** 驾驶状态 / 车辆操作
- **碰撞时** 制动输入 / 车辆响应
- **事故后** 影像回溯 / 三维现场

---

<!-- .slide: class="parallel" data-stage="任务启动" data-active="manager,platform,twin,hardware" data-role-detail="manager=下发任务并协调接口|保证四条任务按同一节奏汇合;platform=开发黑匣子与可信存证|接收并组织事故证据;twin=准备仿真事故与三维环境|负责极端工况和空间复现;hardware=接入方向盘、踏板与DMS|提供真实车端输入" data-collab="manager=任务协调;platform=开发平台;twin=准备仿真;hardware=接入设备" data-cue="四条任务同时开始，后续按完成事件逐步汇合" data-transition="fade" -->
# 车端采集、平台开发和仿真准备同时开始
四个岗位并行推进，完成后汇入同一次事故记录

- **车端** 设备输入与驾驶状态
- **平台** 黑匣子与可信存证
- **仿真** 极端工况与车辆响应
- **联通** 接口协调与结果核对

---

<!-- .slide: class="action" data-stage="车端联调" data-lead="hardware" data-active="hardware,platform,manager" data-role-detail="hardware=执行方向盘与踏板操作|产生真实输入并检查设备响应;platform=观察黑匣子实时数据|确认方向、数值和状态正确显示;manager=发起接口测试并核对结果|确认车端到平台链路打通" data-collab="manager=确认联调;platform=核对数据;hardware=执行操作;twin=准备仿真" data-cue="现场操作发生时，对应数据卡实时高亮" data-transition="slide" -->
# 方向盘和踏板数据进入行车黑匣子
现场操作、采集结果和平台显示同步核对

- **现场操作** 方向盘 / 油门 / 刹车
- **实时采集** 转角与踏板深度
- **平台显示** 黑匣子同步更新

---

<!-- .slide: class="action" data-stage="可信存证" data-lead="platform" data-active="platform,manager" data-role-detail="platform=部署并调用事故存证合约|完成写入、查询和结果展示;manager=提交测试事故记录|核对交易回执与查询结果是否对应" data-collab="manager=核对结果;platform=写入查询;hardware=准备DMS;twin=准备故障工况" data-cue="写入成功后，查询结果自动切换为同一事故记录" data-transition="slide" -->
# 事故数据写入后可再次查询
一次写入对应一次查询，避免只看到“提交成功”

- **提交事故数据** 写入关键记录
- **等待交易结果** 获取实际回执
- **再次查询** 返回本次事故记录

---

<!-- .slide: class="compare" data-stage="极端工况仿真" data-lead="twin" data-active="twin,hardware,platform" data-role-detail="twin=设置正常与制动失效工况|观察相同输入下车辆响应差异;hardware=执行相同的油门与刹车操作|确保两组测试输入可对照;platform=同步记录踏板与碰撞数据|保留仿真过程的事故证据" data-collab="manager=组织验证;platform=记录数据;hardware=执行操作;twin=设置工况" data-cue="重点变化：刹车输入存在，但车辆没有形成正常减速" data-transition="fade" -->
# 仿真中复现“踩刹车但车辆未正常减速”
相同制动操作，在正常工况与故障工况下产生不同结果

| 正常工况 | 制动失效工况 |
| --- | --- |
| 踩下刹车 | 同样踩下刹车 |
| 车辆正常减速 | 车辆未正常减速 |
| **输入与响应一致** | **输入存在，响应异常** |

---

<!-- .slide: class="action" data-stage="DMS验证" data-lead="hardware" data-active="hardware,platform" data-role-detail="hardware=在RK3588运行DMS模型|依次完成正常、低头、闭眼、打电话测试;platform=接收驾驶状态分类结果|核对边缘识别与平台显示是否一致" data-collab="manager=组织验证;platform=核对分类;hardware=执行动作;twin=准备实体事故" data-cue="驾驶状态变化时，边缘识别结果与平台状态同时刷新" data-transition="slide" -->
# DMS在RK3588识别四类驾驶状态
原始图像在边缘端处理，平台只接收驾驶状态结果

- **现场动作** 正常 / 低头 / 闭眼 / 打电话
- **边缘识别** RK3588 本地推理
- **平台核对** 分类状态实时更新

---

<!-- .slide: class="compare" data-stage="实体事故验证" data-lead="manager" data-active="manager,hardware,platform" data-role-detail="manager=组织两组实体事故并控制节奏|确保两组事故独立记录并可对照;hardware=执行制动失效与打电话测试|产生车辆与驾驶状态真实变化;platform=监测行车数据、报警与碰撞记录|保存两组事故的关键证据" data-collab="manager=组织两组事故;platform=记录证据;hardware=执行测试;twin=准备三维重建" data-cue="两次碰撞结果相同，但事故原因需要看不同证据" data-transition="fade" -->
# 两组实体事故留下不同证据
一组观察车辆是否响应制动，另一组观察驾驶员是否及时制动

| 制动失效事故 | 打电话分心事故 |
| --- | --- |
| 已有制动输入 | 持续识别到打电话 |
| 车辆未正常减速 | 达到条件后触发报警 |
| **重点看车辆响应** | **重点看驾驶状态与制动时机** |

---

<!-- .slide: class="timeline" data-stage="事故回溯" data-lead="platform" data-active="platform,manager,twin" data-role-detail="platform=调取事故视频并同步行车数据|把影像、DMS、制动和碰撞标记对齐;manager=选择事故并控制回放时刻|组织评委观察碰撞前后的关键变化;twin=定位碰撞关键帧|为下一步空间关系分析准备输入" data-collab="manager=控制回放;platform=同步证据;hardware=准备VR;twin=定位关键帧" data-cue="碰撞时刻锁定后，前后数据自动定位到同一时间轴" data-transition="slide" -->
# 影像、DMS与制动数据对齐到碰撞时刻
以碰撞为 t＝0，同步查看事故发生前后的连续证据

- **t - 5s** 驾驶状态 / 行车操作
- **t - 2s** 报警 / 制动输入
- **t = 0** 碰撞发生
- **t + 2s** 事故片段保留并关联

---

<!-- .slide: class="scene" data-stage="关键时刻三维化" data-lead="twin" data-active="twin,platform" data-role-detail="twin=提取碰撞帧并执行快速三维化|补充车辆与障碍物的空间关系;platform=提供当前事故关键影像|保证关键帧与事故时间对应" data-collab="manager=确认时刻;platform=提供关键帧;hardware=准备VR;twin=执行三维化" data-transition="fade" -->
# 碰撞关键帧生成三维观察结果
从单帧画面补充碰撞瞬间的空间关系

![关键帧三维结果](assets/scene-keyframe.svg)

- **输入** 当前事故碰撞关键帧
- **输出** 可转动的三维观察结果

---

<!-- .slide: class="scene" data-stage="事故现场重建" data-lead="twin" data-active="twin,manager,platform" data-role-detail="twin=上传手机采集视频并执行3DGS重建|生成可交互的事故后现场;manager=协调重建进度与结果发布|在结果就绪后切换到事故分析环节;platform=建立三维场景与事故记录关联|让交警端能够加载同一次事故现场" data-collab="manager=协调进度;platform=关联场景;hardware=调试VR;twin=执行重建" data-cue="训练完成事件到达后，场景状态从“生成中”切换为“可查看”" data-transition="fade" -->
# 手机采集视频重建事故现场
事故后的整体空间布局转换为可交互三维场景

![3DGS事故现场](assets/scene-3dgs.svg)

- **输入** 事故后手机现场视频
- **输出** 可交互 3DGS 事故现场

---

<!-- .slide: class="evidence" data-stage="证据关联" data-lead="platform" data-active="platform,manager,twin" data-role-detail="platform=把多源资料绑定到同一事故记录|实现一次选择同步调取四类证据;manager=协调AI接口和事故数据|核对当前分析对象始终是同一次事故;twin=发布三维场景与空间信息点|为交警端补充事故现场空间证据" data-collab="manager=核对事故;platform=关联证据;hardware=保持交互;twin=发布场景" data-cue="切换事故记录时，数据、影像、存证和三维场景同步切换" data-transition="slide" -->
# 交警端把四类事故证据关联到同一记录
选择一次事故，即可同步调取对应资料

## 当前事故记录

- **行车数据** 驾驶操作与车辆响应
- **关键影像** 碰撞前后视频与关键帧
- **可信存证** 写入结果与查询记录
- **三维现场** 位置关系与场景重建

---

<!-- .slide: class="reasoning" data-stage="AI辅助分析" data-lead="manager" data-active="manager,platform,twin,hardware" data-role-detail="manager=发起事故分析并解释证据关系|把分析结果与现场操作过程对应;platform=组织事故证据并展示模型返回结果|确保结论可以回到原始记录;twin=提供三维现场与空间信息|补充碰撞区域和车辆位置关系;hardware=提供DMS、报警与制动记录|核对驾驶行为和制动时机" data-collab="manager=解释分析;platform=组织证据;twin=提供空间信息;hardware=核对DMS" data-cue="分析结果出现时，对应证据项同步高亮，而不是只显示一句结论" data-transition="slide" -->
# 分心事故分析由三项证据共同支撑
驾驶状态、报警时刻和制动时机连续对应到碰撞结果

- **持续打电话** DMS记录分心状态
- **触发报警** 达到设定条件后报警
- **制动偏晚** 碰撞前未及时形成有效制动

## 辅助分析：驾驶员分心与制动延迟存在关联

---

<!-- .slide: class="scene" data-stage="VR现场勘查" data-lead="hardware" data-active="hardware,twin,manager" data-role-detail="hardware=佩戴VR并执行多角度现场观察|验证场景加载和交互连续性;twin=连接三维场景并提供设备辅助|保证VR看到的是当前事故现场;manager=组织安全确认与观察顺序|引导查看碰撞区域和车辆位置" data-collab="manager=组织勘查;platform=保持资料;hardware=操作VR;twin=连接场景" data-cue="VR视角变化可实时投屏，评委看到的画面与操作者同步" data-transition="fade" -->
# VR进入同一事故三维现场
操作者的观察视角实时投到大屏，支持多角度查看碰撞区域

![VR事故现场](assets/scene-vr.svg)

- **加载** 当前事故三维场景
- **观察** 碰撞区域 / 车辆位置 / 周围环境

---

<!-- .slide: class="results" data-stage="系统级联合验收" data-active="manager,platform,twin,hardware" data-role-detail="manager=执行批量写入并组织结果汇总|控制四项任务同时运行的验收节奏;platform=核对写入成功、失败与查询结果|记录平台侧真实表现;twin=并行启动并观察3DGS训练任务|核对任务状态与生成结果;hardware=持续观察DMS与VR|核对边缘推理和交互稳定性" data-collab="manager=组织验收;platform=核对写入;twin=观察3DGS;hardware=观察DMS/VR" data-cue="本页数值支持实时更新，只显示本轮现场实测结果" data-transition="fade" -->
# 四项任务同时运行进行联合验收
存证、三维训练、DMS和VR在同一轮测试中并行观察

| 验收项目 | 本轮状态 | 核对内容 |
| --- | --- | --- |
| 事故记录写入 | — | 成功 / 失败 / 查询结果 |
| 3DGS训练任务 | — | 任务状态 / 生成结果 |
| DMS边缘推理 | 待核对 | 状态识别 / 报警 |
| VR场景交互 | 待核对 | 加载 / 交互 / 连续性 |

---

<!-- .slide: class="closing" data-stage="项目交付" data-active="manager,platform,twin,hardware" data-role-detail="manager=汇总系统联通与联合验收|说明四条能力如何形成完整业务链;platform=汇报证据平台与可信存证|说明事故资料如何集中查询;twin=汇报仿真验证与三维重建|说明事故空间复现能力;hardware=汇报车端采集、DMS与VR|说明现场设备和边缘能力" data-collab="manager=汇总闭环;platform=证据平台;twin=仿真/三维;hardware=车端/DMS/VR" data-transition="fade" -->
# 行车记录、存证、三维现场和分析完成闭环
四个岗位的结果最终汇入同一次事故证据链

- **采集事故** 人、车状态形成连续记录
- **留下证据** 关键事故数据可查询、可核对
- **还原现场** 关键帧、3DGS与VR补充空间信息
- **辅助分析** 分析结果能够回到原始依据
